package com.springboot.bookcart.service;

import com.springboot.bookcart.model.Author;

public interface DetailAuthorService {
Author saveAuthor(Author author);
}
